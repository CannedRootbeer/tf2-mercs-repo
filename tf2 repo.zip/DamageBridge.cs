using System;
using System.Reflection;
using UnityEngine;

namespace TF2MercsRepo
{
    // The ONLY place that knows how R.E.P.O. applies damage. Verify names against Assembly-CSharp.dll
    // (dnSpy / ILSpy) and replace the reflection with direct calls or Harmony patches.
    public static class DamageBridge
    {
        // GUESSES, to verify:
        static readonly string[] EnemyTypeHints  = { "Enemy", "EnemyHealth" };
        static readonly string[] PlayerTypeHints = { "PlayerAvatar", "PlayerHealth" };
        static readonly string[] DamageMethods   = { "Hurt", "TakeDamage", "Damage" };

        public static void Apply(Collider col, float amount, Vector3 from)
        {
            if (amount <= 0) return;
            foreach (var mb in col.GetComponentsInParent<MonoBehaviour>())
            {
                var t = mb.GetType();
                bool isPlayer = Matches(t, PlayerTypeHints);
                bool isEnemy  = Matches(t, EnemyTypeHints);
                if (!isPlayer && !isEnemy) continue;
                if (isPlayer && !Plugin.PvP.Value) return;      // co-op: no damage to players
                // TODO: skip self and, if desired, teammates.
                if (TryInvoke(mb, amount)) return;
            }
        }

        static bool Matches(Type t, string[] hints)
        {
            foreach (var h in hints) if (t.Name.Contains(h)) return true;
            return false;
        }

        static bool TryInvoke(object target, float amount)
        {
            foreach (var name in DamageMethods)
            {
                foreach (var m in target.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (m.Name != name) continue;
                    var ps = m.GetParameters();
                    try
                    {
                        if (ps.Length == 1 && ps[0].ParameterType == typeof(int))   { m.Invoke(target, new object[] { Mathf.RoundToInt(amount) }); return true; }
                        if (ps.Length == 1 && ps[0].ParameterType == typeof(float)) { m.Invoke(target, new object[] { amount }); return true; }
                    }
                    catch (Exception e) { Plugin.Log.LogWarning($"Damage call {name} failed: {e.Message}"); }
                }
            }
            return false;
        }
    }
}
