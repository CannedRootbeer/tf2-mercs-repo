using System.Reflection;
using UnityEngine;

namespace TF2MercsRepo
{
    // v1 input uses Unity's legacy Input. R.E.P.O. may use the new Input System: if axes
    // are dead, swap to UnityEngine.InputSystem. F6 cycles class, 1/2/3 pick slot, LMB fires, R reloads.
    public class MercController : MonoBehaviour
    {
        ClassDef cls;
        int slot;
        int[] ammo = new int[3];
        float nextFire, reloadUntil;
        string[] ids = { "scout", "soldier", "pyro", "demoman", "heavy", "engineer", "medic", "sniper", "spy" };

        void Start() { SetClass(Plugin.ClassId.Value); }

        void SetClass(string id)
        {
            foreach (var c in Sheets.Classes) if (c.id == id) cls = c;
            if (cls == null) cls = Sheets.Classes[0];
            Plugin.ClassId.Value = cls.id;
            for (int i = 0; i < 3; i++) ammo[i] = Sheets.Weapon(cls.loadout[i]).clip;
            slot = 0;
            // TODO(R.E.P.O.): apply cls.health to the local player's health and cls.speedMult to movement.
        }

        WeaponDef Current => Sheets.Weapon(cls.loadout[slot]);

        void Update()
        {
            if (cls == null || Camera.main == null) return;
            if (Input.GetKeyDown(KeyCode.F6))
            {
                int i = System.Array.IndexOf(ids, cls.id);
                SetClass(ids[(i + 1) % ids.Length]);
            }
            if (Input.GetKeyDown(KeyCode.Alpha1)) slot = 0;
            if (Input.GetKeyDown(KeyCode.Alpha2)) slot = 1;
            if (Input.GetKeyDown(KeyCode.Alpha3)) slot = 2;
            if (Input.GetKeyDown(KeyCode.R)) TryReload();

            var w = Current;
            if (Time.time < reloadUntil || Time.time < nextFire) return;
            bool wantsFire = (w.rpm >= 300 || w.kind == "beam") ? Input.GetMouseButton(0) : Input.GetMouseButtonDown(0);
            if (!wantsFire) return;
            if (w.clip > 0 && ammo[slot] <= 0) { TryReload(); return; }
            Fire(w);
        }

        void TryReload()
        {
            var w = Current;
            if (w.clip <= 0 || ammo[slot] == w.clip) return;
            reloadUntil = Time.time + w.reload;
            ammo[slot] = w.clip;
        }

        void Fire(WeaponDef w)
        {
            if (w.rpm > 0) nextFire = Time.time + 60f / w.rpm;
            if (w.clip > 0) ammo[slot]--;
            var cam = Camera.main.transform;

            if (w.kind == "heal" || w.kind == "none") return; // TODO: medigun heals teammates; sapper unused in v1

            for (int p = 0; p < Mathf.Max(1, w.pellets); p++)
            {
                var dir = cam.forward;
                if (w.spread > 0) dir = Quaternion.AngleAxis(Random.Range(0f, 360f), cam.forward) *
                                        Quaternion.AngleAxis(Random.Range(0f, w.spread), cam.up) * dir;
                if (Physics.Raycast(cam.position, dir, out var hit, w.range, ~0, QueryTriggerInteraction.Ignore))
                {
                    if (w.splash > 0) Splash(hit.point, w);
                    else DamageBridge.Apply(hit.collider, w.damage, cam.position);
                }
            }
        }

        void Splash(Vector3 point, WeaponDef w)
        {
            foreach (var c in Physics.OverlapSphere(point, w.splash))
            {
                float falloff = 1f - Vector3.Distance(point, c.ClosestPoint(point)) / w.splash * 0.5f;
                DamageBridge.Apply(c, w.damage * falloff, point);
            }
        }

        void OnGUI()
        {
            if (cls == null) return;
            var w = Current;
            GUI.Label(new Rect(20, Screen.height - 70, 500, 24),
                $"{cls.name}  [{slot + 1}] {w.name}  {(w.clip > 0 ? ammo[slot] + "/" + w.clip : "")}   (F6 class, PvP: {(Plugin.PvP.Value ? "ON" : "off")})");
        }
    }
}
