using System;
using System.IO;
using System.Linq;
using UnityEngine;

namespace TF2MercsRepo
{
    [Serializable] public class ClassDef { public string id, name; public int health; public float speedMult; public string[] loadout; }
    [Serializable] public class WeaponDef
    {
        public string id, name, kind; public int slot, pellets, clip;
        public float damage, spread, rpm, range, reload, splash;
    }
    [Serializable] class ClassFile { public ClassDef[] classes; }
    [Serializable] class WeaponFile { public WeaponDef[] weapons; }

    // Sheets (JSON) are the source of truth; code reads them at start.
    public static class Sheets
    {
        public static ClassDef[] Classes;
        public static WeaponDef[] Weapons;

        public static void Load(string dir)
        {
            Classes = JsonUtility.FromJson<ClassFile>(File.ReadAllText(Path.Combine(dir, "classes.json"))).classes;
            Weapons = JsonUtility.FromJson<WeaponFile>(File.ReadAllText(Path.Combine(dir, "weapons.json"))).weapons;
            Preflight();
        }

        public static WeaponDef Weapon(string id) => Weapons.FirstOrDefault(w => w.id == id);

        // Every loadout reference must resolve to a weapon row.
        static void Preflight()
        {
            foreach (var c in Classes)
                foreach (var wid in c.loadout)
                    if (Weapon(wid) == null)
                        Plugin.Log.LogError($"Preflight: class '{c.id}' references missing weapon '{wid}'");
        }
    }
}
