using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using System.IO;
using UnityEngine;

namespace TF2MercsRepo
{
    [BepInPlugin("com.tf2mercs.repo", "TF2 Mercs in R.E.P.O.", "0.1.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static ManualLogSource Log;
        public static ConfigEntry<bool> PvP;          // lobby toggle (host's value should win; see TODO in Net)
        public static ConfigEntry<string> ClassId;    // chosen class
        public static ConfigEntry<string> JoinAddress; // Melty: empty = host

        void Awake()
        {
            Log = Logger;
            PvP = Config.Bind("Lobby", "PvP", false, "Allow TF2 weapons to damage other players.");
            ClassId = Config.Bind("Player", "Class", "soldier", "scout, soldier, pyro, demoman, heavy, engineer, medic, sniper, spy");
            JoinAddress = Config.Bind("Melty", "join", "", "Set by Melty at launch.");

            var dir = Path.Combine(Path.GetDirectoryName(Info.Location), "data");
            Sheets.Load(dir);
            Tf2Assets.Init();

            var go = new GameObject("TF2MercsRepo");
            DontDestroyOnLoad(go);
            go.hideFlags = HideFlags.HideAndDontSave;
            go.AddComponent<MercController>();
            Log.LogInfo("TF2 Mercs loaded.");
        }
    }
}
