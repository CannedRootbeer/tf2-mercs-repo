# TF2 Mercs in R.E.P.O. (v0.1, UNTESTED SKELETON)

Play as the 9 TF2 classes inside R.E.P.O. with stock weapons that damage monsters (and players when PvP is on).
Host game: R.E.P.O. (BepInEx 5). Companion: Team Fortress 2, read from the player's own install; nothing from TF2 is shipped.

Status: written without R.E.P.O.'s assemblies and never compiled or run.
- `data/*.json` are the source-of-truth sheets (classes, weapons). Weapon numbers are approximate.
- `DamageBridge.cs` is the one place with guessed R.E.P.O. type/method names. Verify with dnSpy/ILSpy.
- TODO: apply class health/speed, lobby class picker UI, PvP toggle sync from host, VPK reader for TF2 sounds,
  multiplayer via recipe.multiplayer (R.E.P.O. uses Photon; use its lobby, don't invent a server), Melty recipe + test.

Build: `dotnet build -p:RepoDir="C:\path\to\REPO"`; copy `TF2MercsRepo.dll` and `data/` to `BepInEx/plugins/TF2MercsRepo/`.
License: MIT (to be added as LICENSE). Remixing allowed.
