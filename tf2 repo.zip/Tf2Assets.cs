using System;
using System.IO;

namespace TF2MercsRepo
{
    // Locates the player's own TF2 install. Nothing from it is copied or shipped.
    public static class Tf2Assets
    {
        public static string Dir;          // TF2 root (contains the "tf" folder)
        public static bool Available => Dir != null;

        public static void Init()
        {
            // TODO(verify): the exact env var name Melty uses for "{game:team-fortress-2}".
            // Declare it in the recipe launch environment, e.g. MERCS_TF2_DIR={game:team-fortress-2}
            var d = Environment.GetEnvironmentVariable("MERCS_TF2_DIR");
            if (!string.IsNullOrEmpty(d) && Directory.Exists(Path.Combine(d, "tf")))
                Dir = d;
            Plugin.Log.LogInfo(Available ? $"TF2 found at {Dir}" : "TF2 not found: running with placeholder audio/visuals.");
        }

        // TODO: read tf/tf2_sounds_misc_dir.vpk and tf2_sounds_vo_english_dir.vpk (VPK v2 directory + _NNN archives),
        // extract wav entries in memory (e.g. vo/soldier_battlecry01.mp3) and wrap in UnityEngine.AudioClip.
        public static UnityEngine.AudioClip LoadSound(string vpkPath) { return null; }
    }
}
